from enum import Enum

class MatchStatus(Enum):
    Playing  = 'Playing'
    YetToStart = 'YetToStart'
    Finished = 'Finished'